## EDA Integrated - per Sector Rmd

This folder contains all of the code for the EDA portion of our analysis, organized by sector.

## Macro Data + FF5 Data

This folder contains the necessary data for our microenvironmental factors (CCI, M2 Supply, Unemployment, and VIX). It also contains the necessary data for the 5 factors of the Fama-French 5-Factor model.

## Panel Data - per Sector Data

This folder contains the necessary data developed from our code in the folder "Panel Data Code + Reg - per Sector Rmd" - the data used in the panel regression. We take the ticker data, stored in "Tickers - Data and Code" to retrieve the WRDS returns, financial ratio, and fundamental data for the appropriate tickers.

## Panel Data Code + Reg - per Sector Rmd

This folder contains all of our code to create the residual returns. We use data from the FF5, macro data, and pull the returns (to develop the residuals), ratios, and fundamentals here. We clean the data in this code as well. Finally we merge these data sets to create our panel data. These codes are separated by sector, being a variation of "panel_[sector]_st_FINAL.rmd". 

The file "combined_panel.rmd" is where we use these residual data sets and create our train and test data sets to develop our models for analysis.

## Tickers - Data Code

This folder contains the code used to get the ticker data from the iShare ETFS for each sector used.